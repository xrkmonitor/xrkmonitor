#include <StdoutLog.h>
#include <SocketHandler.h>
#include "UdpTestSocket.h"


int main(int argc,char *argv[])
{
	SocketHandler h;
	StdoutLog log;
	h.RegStdLog(&log);
	UdpSocket s(h);

	s.SendTo("localhost", 5000, "Using SendTo with address to send");
	if (!s.Open("127.0.0.1", 5000))
	{
		printf("Exiting...\n");
		exit(-1);
	}
	for (int i = 0; i < argc; i++)
	{
		s.Send(argv[i]);
	}
}


