#ifndef _UDPTESTSOCKET_H
#define _UDPTESTSOCKET_H

#include <UdpSocket.h>


class UdpTestSocket : public UdpSocket
{
public:
	UdpTestSocket(ISocketHandler&);

	void OnRawData(const char *,size_t,struct sockaddr *,socklen_t);
};


#endif // _UDPTESTSOCKET_H
