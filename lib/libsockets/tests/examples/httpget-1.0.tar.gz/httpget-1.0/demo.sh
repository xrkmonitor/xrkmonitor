#!/bin/sh
./httpget2 \
	http://www.alhem.net/index.html \
	http://www.alhem.net/mysql.html \
	http://www.alhem.net/applesoft.html \
	http://www.alhem.net/image/ah.jpg \
	http://www.alhem.net/buggg.htm
