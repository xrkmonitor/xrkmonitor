/**
 **	File ......... key.cpp
 **	Published ....  2004-04-19
 **	Author ....... grymse@alhem.net
**/
/*
Copyright (C) 2004  Anders Hedstrom

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
	unsigned char k1[32] =
	{
		0x00,0x63,0x76,0xd4, 0x63,0x98,0x47,0x0a,
		0xab,0xd1,0x98,0xe6, 0x9a,0xe4,0x49,0x07,
		0xb9,0x44,0xfd,0x68, 0xf9,0xa7,0x4c,0x06,
		0x83,0xf3,0xa5,0xc5, 0x03,0x42,0x94,0xa0,
	};


