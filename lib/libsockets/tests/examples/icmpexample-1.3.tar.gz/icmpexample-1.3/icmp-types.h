ICMP defines the following message types

Message Number 	Message Type 			Meaning
---------------------------------------------------------------------------------------------------
	 0 	Echo Reply 			Reply to Echo Request
	 3 	Destination Unreachable 	Network or Host unknown
	 4 	Source Quench 			Message too long or arrived too soon
	 5 	Redirect 			The host can be reached through a different gateway
	 8 	Echo Request 			Requests gateway/host to return sent data
	11 	Time Exceeded 			TTL exceeded
	12 	Parameter Problem 		Bad parameter in message header
	13 	Timestamp 			Requests gateway/host time in mSec
	14 	Timestamp Reply 		Gateway/host time in mSec
	15 	Information Request 		Request host network number
	16 	Information Reply 		Host network number
