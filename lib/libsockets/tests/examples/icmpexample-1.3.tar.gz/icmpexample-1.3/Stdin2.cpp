/**
 **	File ......... Stdin2.cpp
 **	Published ....  2004-07-03
 **	Author ....... grymse@alhem.net
**/
/*
Copyright (C) 2004  Anders Hedstrom
Parts Copyright (c) Vergil of Ragestorm.net, 2003

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <errno.h>
#include "ISocketHandler.h"
#include "ICMPTwistSocket.h"
#include "Stdin2.h"




Stdin2::Stdin2(ISocketHandler& h) : Stdin(h)
,m_pICMPSocket(NULL)
{
}


void Stdin2::OnData(const char *p,size_t len)
{
	char buf[1000];
	strncpy(buf, p, len);
	buf[len] = 0;
	while (strlen(buf) && (buf[strlen(buf) - 1] == 13 || buf[strlen(buf) - 1] == 10))
		buf[strlen(buf) - 1] = 0;
	//printf("Console(%d bytes): %s\n", n, buf);
	if (m_pICMPSocket)
	{
		m_pICMPSocket -> Send( buf );
	}
}


